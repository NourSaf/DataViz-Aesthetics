export const width = 1300, 
             height = 600, 
             margin = {
              top:40, right:30, bottom:50, left:50
            };

